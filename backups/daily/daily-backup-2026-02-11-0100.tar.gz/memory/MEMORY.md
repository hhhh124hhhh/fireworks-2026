# MEMORY.md - 长期记忆

*此文件包含重要的长期记忆，需要在 main session 中加载*
*备份目录：/root/clawd/memory/backups*

## 重要记忆

*此部分保留最重要的长期记忆，不会被清理*

## 2026-02-10 重要决策

### 1. 服务器定位和架构

**服务器类型**: 轻量云（36G 磁盘）

**核心定位**: AI 协同中枢（中转枢纽）

**角色**:
- ✅ AI 助手（轻量级）
- ✅ 自动化任务管理
- ✅ 技能开发和管理
- ✅ AI Content Creator（使用云存储）
- ✅ 智能路由和编排
- ❌ 不是大型应用服务器
- ❌ 不是数据库服务器
- ❌ 不是文件存储服务器

**架构模式**:
- Serverless（API 网关、Bot 服务）
- 轻量服务器（主服务）
- 云存储（百度云 BOS、OSS/COS）
- 多服务协同

---

### 2. 磁盘管理策略

**优化成果**:
- 使用率: 81% → 75%
- 释放空间: 2.2GB

**清理内容**:
- venv-prompt-hunter: 1.3G
- 交互演示 node_modules: 670M
- AI Prompt Marketplace node_modules: 415M
- .pyc 文件: ~100M
- __pycache__: ~200M
- pip 缓存: ~300M
- 旧备份: ~50M
- 旧日志: ~100M

**策略**:
- 删除冗余虚拟环境
- 删除可重建的 node_modules
- 定期清理缓存和临时文件
- 依赖云存储（百度云 BOS）

---

### 3. 自动备份系统 ⭐⭐⭐

#### 每日备份
- **时间**: 每天 1:00
- **脚本**: daily-backup.sh
- **内容**: memory、docs、配置文件
- **保留**: 7 天
- **状态**: ✅ 已测试

#### Git 同步
- **时间**: 每天 1:30
- **脚本**: git-sync.sh
- **仓库**: https://github.com/hhhh124hhhh/jack-portfolio.git
- **内容**: 代码、配置、文档
- **状态**: ✅ 已配置

#### 备份状态检查
- **时间**: 每小时
- **脚本**: backup-status.sh
- **功能**: 检查备份状态、生成报告
- **状态**: ✅ 已配置

#### Cron 任务（3 个）
1. 每天 1:00: 每日备份
2. 每天 1:30: Git 同步
3. 每小时: 状态检查

---

### 4. AI Content Creator 自动化策略

**问题**: 上下文溢出（SSE stream 输出污染主上下文）

**解决方案**: 使用子代理（sessions_spawn）

**子代理 1（大纲生成）**:
- 任务: 运行 PPT 大纲生成
- 输出: query_id, chat_id, title
- 隔离: 完全独立的上下文空间

**子代理 2（PPT 生成）**:
- 任务: 使用大纲信息生成 PPT
- 输入: query_id, chat_id, title
- 隔离: 完全独立的上下文空间

**优势**:
- 主上下文保持干净
- SSE stream 输出不污染
- 可复用子代理模板

**参考**: `/root/clawd/memory/context-overflow-solution.md`

---

### 5. Slack 推送工具

#### md-to-slack.sh
- **功能**: 将 MD 文件转换为 Slack 友好格式
- **模式**: summary（前 100 行）、full（全部）、tag（特定标签）
- **用途**: 用户无法访问服务器时查看文件

#### summary-to-slack.sh
- **功能**: 自动推送任务摘要
- **模式**: morning（任务列表）、evening（进度）、night（计划）、all（全部）
- **用途**: 自动推送每日总结

**参考**: `/root/clawd/docs/slack-push-tools-config.md`

---

## 技能和工具

### 已配置的技能
- baidu-scholar-search-skill (v1.0.3)
- baidu-search (v1.0.5)
- ai-ppt-generate (v1.0.0)
- ai-picture-book (v1.0.5)

### 已创建的脚本

#### 备份相关（4 个）
- daily-backup.sh - 每日备份
- git-sync.sh - Git 同步
- backup-status.sh - 备份状态检查
- setup-backup-cron.sh - 配置备份 Cron

#### 清理和归档（3 个）
- cleanup-old-files.sh - 清理 7 天前的文件
- rclone-backup.sh - Rclone 多云备份
- auto-archive.sh - 自动归档 30 天前的文件

#### 推送工具（2 个）
- md-to-slack.sh - MD 转换
- summary-to-slack.sh - 摘要推送

#### 其他脚本
- twitter-search-cron.sh - Twitter 自动搜索
- sync-to-baidu-cloud-v2.sh - 百度云同步

---

## Cron 任务配置

### 当前总任务数: 10 个

#### 备份相关（3 个）
- 每天 1:00: 每日备份
- 每天 1:30: Git 同步
- 每小时: 备份状态检查

#### 清理和归档（3 个）
- 每天 2:00: 百度云同步
- 每天 2:00: 自动归档（每周日）
- 每天 3:00: 清理旧文件

#### 系统维护（2 个）
- 每天 3:00: Gateway 自动重启
- 每小时: Gateway CPU 监控

#### 业务任务（2 个）
- 每天 4:00: Rclone 备份
- 每天 9:00: AI 研究推送

---

## 2026-02-10 工作总结

### 完成的主要任务

1. ✅ AI Content Creator 自动化（大纲生成完成，PPT 进行中）
2. ✅ 磁盘清理（释放 2.2GB，使用率 81% → 75%）
3. ✅ 修复 Twitter 搜索脚本
4. ✅ 配置百度云自动同步
5. ✅ 配置自动清理和归档
6. ✅ 配置 Rclone 多云备份
7. ✅ 配置自动备份系统（每日备份 + Git 同步 + 状态检查）

### 创建的文件

#### 脚本（10 个）
- daily-backup.sh
- git-sync.sh
- backup-status.sh
- cleanup-old-files.sh
- rclone-backup.sh
- auto-archive.sh
- md-to-slack.sh
- summary-to-slack.sh
- twitter-search-cron.sh
- sync-to-baidu-cloud-v2.sh

#### 配置文件
- MEMORY.md
- backup-system-config.md
- slack-push-tools-config.md
- context-overflow-solution.md

---

## 关键文件位置

### 记忆文件
- `/root/clawd/memory/MEMORY.md` - 长期记忆（本文件）
- `/root/clawd/memory/YYYY-MM-DD.md` - 每日记忆

### 配置文件
- `/root/clawd/IDENTITY.md` - 身份配置
- `/root/clawd/USER.md` - 用户信息
- `/root/clawd/SOUL.md` - 灵魂配置
- `/root/clawd/AGENTS.md` - 配置文件

### 文档
- `/root/clawd/docs/backup-system-config.md` - 备份系统配置
- `/root/clawd/docs/slack-push-tools-config.md` - Slack 推送配置
- `/root/clawd/memory/context-overflow-solution.md` - 上下文溢出解决方案

### 脚本
- `/root/clawd/scripts/` - 所有脚本

---

## 未来规划

### 短期（1-2 周）
- ⏳ 首次 Git 推送
- ⏳ 配置百度云 BOS 上传
- ⏳ 配置告警通知
- ⏳ 完成 AI Content Creator PPT 生成

### 中期（1-2 个月）
- ⏳ 多云备份（阿里云 OSS、腾讯云 COS）
- ⏳ 自动恢复脚本
- ⏳ 备份验证脚本
- ⏳ Serverless 迁移（API 网关、Bot 服务）

### 长期（3 个月以上）
- ⏳ 备份加密
- ⏳ 异地备份
- ⏳ 备份性能优化
- ⏳ 全面轻量云架构

---

## 总结

**服务器定位**: 轻量云 AI 协同中枢

**核心策略**:
1. 依赖外部服务（AI、存储、数据库）
2. 自动化备份（每日 + Git + 多云）
3. 数据持久化（Git 版本控制）
4. 轻量级部署（Serverless + 轻量服务器）

**优势**:
- 成本低
- 可扩展
- 高可用
- 易运维

**一句话**: "轻量云 + 外部服务协同 = AI 助手的最佳部署方式！"

---

*最后更新: 2026-02-10*
*状态: ✅ 备份系统已配置并测试*
