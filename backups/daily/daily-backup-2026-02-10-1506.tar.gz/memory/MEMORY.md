# MEMORY.md - 长期记忆

*此文件包含重要的长期记忆，需要在 main session 中加载*
*备份目录：/root/clawd/memory/backups*

## 重要记忆

*此部分保留最重要的长期记忆，不会被清理*

## 2026-02-10 重要决策

1. **AI Content Creator 自动化策略**: 使用子代理解决上下文溢出问题
2. **磁盘管理策略**: 删除冗余文件，依赖云存储
3. **备份策略**: 每日备份 + Git 同步 + 多云备份
4. **轻量云架构**: 中转枢纽 + 外部服务协同

## 备份策略

### 每日备份
- 时间: 每天 1:00
- 内容: memory、docs、配置文件
- 保留: 7 天

### Git 同步
- 时间: 每天 1:30
- 仓库: https://github.com/hhhh124hhhh/jack-portfolio.git
- 内容: 代码、配置、文档

### 状态检查
- 时间: 每小时
- 功能: 生成备份状态报告

## 技能和工具

### 已配置的技能
- baidu-scholar-search-skill
- baidu-search
- ai-ppt-generate
- ai-picture-book

### 已创建的脚本
- daily-backup.sh - 每日备份
- git-sync.sh - Git 同步
- backup-status.sh - 备份状态检查

## 2026-02-10 优化成果

### 磁盘优化
- 使用率: 81% → 75%
- 释放空间: 2.2GB

### 自动化配置
- 10 个 Cron 任务
- 备份、清理、归档

### 服务器定位
- 角色: AI 协同中枢（中转枢纽）
- 部署: 轻量云
- 策略: 连接外部服务

---

*最后更新: 2026-02-10*
